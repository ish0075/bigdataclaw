---
type: property
address: 75 Ormond Street South, Thorold, ON
price: 4820000
status: spa_approved
units: 241
acres: 1.7
asset_class: multi_residential
created: 2026-03-09
asking_price: 4820000
---

# 75 Ormond Street South, Thorold

## 📍 Property Details
- **Address:** 75 Ormond Street South, Thorold, ON
- **Price:** $4,820,000
- **Status:** ✅ SPA Approved
- **Asset Class:** Multi-Residential Development
- **Units:** 241
- **Size:** 1.7 acres
- **Height:** 9-14 storeys
- **Buildable:** 249,541 sq ft GFA

## 🌟 Key Features
- ✅ **SPA APPROVED** - ready to build immediately
- ✅ Phase 1 & 2 Environmental Site Assessment complete
- ✅ 5 minutes from Brock University
- ✅ 15 minutes from Niagara Falls
- ✅ Strong rental market (student housing + tourists)
- ✅ Zoning in place, no rezoning needed

## 📊 Investment Metrics
- **Price per unit:** $20,000
- **Price per acre:** $2.84M
- **Price per sq ft:** $19.32
- **Proforma rents:** $1,800-2,400/unit/month

## 🎯 Buyer Matches

| Rank | Buyer | Score | Phone | Status |
|------|-------|-------|-------|--------|
| 1 | [[Glen Alizadeh]] | 95% | 905-452-1305 | 🔥 Call Today |
| 2 | [[Christopher Zeppa]] | 92% | 905-552-5200 | 🔥 Call Today |
| 3 | [[Michael Rockall]] | 93% | 905-452-1305 | 🔥 Call Today |
| 4 | [[David Barry]] | 90% | Find phone | 🎯 Research |
| 5 | [[Max Elkaim]] | 88% | 647-729-9552 | 🎯 Call This Week |

## 📝 Activity Log
| Date | Activity | Contact | Result |
|------|----------|---------|--------|
| 2026-03-09 | Listed | - | Active |

## 📧 Marketing

### Listing Status:
- [ ] LoopNet listing created
- [ ] Broker outreach sent
- [ ] LinkedIn posts
- [ ] Facebook groups posted
- [ ] Direct to hot money sellers

### Target Buyers:
- Niagara region developers
- Student housing specialists
- Cash buyers with $5-20M capacity
- 1031 exchange buyers

## 📄 Documents
- [ ] Site Plan
- [ ] SPA Documents
- [ ] Environmental Reports
- [ ] Pro Forma Financials
- [ ] Market Study

## 🗺️ Location
```leaflet
latitude: 43.1236
longitude: -79.1981
```

## 💬 Notes
- [ ] Call Glen Alizadeh (905-452-1305) - St. Catharines local, $16M cash
- [ ] Call Christopher Zeppa (905-552-5200) - Land developer specialist
- [ ] Find David Barry contact (owns 79-unit in St. Catharines)
- [ ] Research $102M London seller (PIN: 08090-1293+) - potential cross-asset buyer

---

#listing #thorold #niagara #multi-residential #spa-approved #development