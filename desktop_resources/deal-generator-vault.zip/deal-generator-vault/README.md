# 🎯 Deal Generator - Obsidian Vault

Your personal commercial real estate deal-making headquarters.

## 📁 Vault Structure

```
deal-generator-vault/
├── 📄 00 - DASHBOARD.md              ← START HERE - Daily command center
│
├── 📁 Buyers/                         ← All buyer profiles
│   ├── Hot_Money/                     🔥 Recent sellers with cash (priority)
│   ├── Warm_Leads/                    🎯 Qualified but not urgent
│   ├── Cold_Leads/                    💡 Nurture campaign
│   └── Closed/                        ✅ Deals done
│
├── 📁 Sellers/                        ← Recent sellers (potential buyers)
│   └── Hot_Money/                     💰 Fresh capital to deploy
│
├── 📁 Properties/                     ← Your listings
│   ├── Active/                        🏢 Currently for sale
│   ├── Under_Contract/                ⏳ In negotiation
│   └── Past/                          📚 Closed deals (reference)
│
├── 📁 Lenders/                        ← Financing sources
│   ├── Banks/
│   ├── Private_MICs/
│   └── Credit_Unions/
│
├── 📁 Brokers/                        ← Broker relationships
│   ├── National/                      (CBRE, JLL, etc.)
│   └── Boutique/                      (Regional specialists)
│
├── 📁 Scripts/                        ← Outreach materials
│   ├── Calls/                         📞 Phone scripts
│   ├── Emails/                        ✉️ Email templates
│   ├── LinkedIn/                      💼 LinkedIn messages
│   └── SMS/                           💬 Text templates
│
├── 📁 Daily/                          ← Activity logs
│   └── 2026/                          Organized by year
│
├── 📁 Templates/                      ← Note templates
│   ├── Buyer Profile.md
│   ├── Daily Note.md
│   └── Property Listing.md
│
└── 📁 Archive/                        ← Old/irrelevant notes
```

## 🚀 Daily Workflow

### Morning (5 minutes):
1. Open **[[00 - DASHBOARD]]**
2. Review 🔥 HOT LEADS section
3. Check today's priorities
4. Click into today's [[Daily/{{date:YYYY-MM-DD}}|Daily Note]]

### Throughout Day:
- Log calls in Daily Note (auto-links to buyer profiles)
- Update buyer profiles after conversations
- Add new leads to appropriate folder

### End of Day (5 minutes):
- Update Dashboard metrics
- Set tomorrow's priorities
- Sync with Kimi Claw AI

## 🔗 Key Links

- **Dashboard:** [[00 - DASHBOARD]]
- **Thorold Property:** [[75 Ormond St S - Thorold]]
- **Today's Note:** [[Daily/{{date:YYYY-MM-DD}}]]
- **Call Scripts:** [[Scripts/Calls/Thorold Property]]

## 🎯 First Close Roadmap (30-90 Days)

| Week | Focus | Target |
|------|-------|--------|
| 1 | Set up systems, import data | Vault organized, website live |
| 2 | First calls to hot leads | 10 conversations |
| 3 | Follow-ups, social outreach | 3 serious prospects |
| 4 | Meetings, site visits | 1 LOI in hand |
| 5-8 | Negotiation, due diligence | Deal structure |
| 9-12 | Close first deal | 🎉 FIRST CLOSE |

## 🐝 Kimi Claw AI Integration

This vault syncs with Kimi Claw AI:
- ✅ Daily notes auto-created
- ✅ Buyer profiles auto-generated from database
- ✅ Hot money alerts appear automatically
- ✅ Call logs sync both ways

**Connection:** Via Local REST API plugin (see setup guide)

## 📊 Dataview Queries

Use these queries in any note:

### Show all hot money sellers:
```dataview
TABLE 
  total_value as "Deal Size",
  days_since_close as "Days"
FROM "Sellers/Hot_Money"
SORT total_value DESC
```

### Show buyers to call today:
```dataview
TABLE 
  match_score as "Score",
  company_phone as "Phone"
FROM "Buyers/Hot_Money"
WHERE status = "new"
SORT match_score DESC
```

## 🔒 Backup & Sync

This vault should be synced via:
- **Git** (recommended) - Private GitHub repo
- **Obsidian Sync** (official) - Paid service
- **iCloud/Dropbox** - Simple file sync

**Never lose your data!**

---

*Built with ❤️‍🔥 by Kimi Claw AI for Deal Generator*