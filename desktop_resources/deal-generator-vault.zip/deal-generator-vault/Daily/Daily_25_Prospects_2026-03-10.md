# Daily 25 Prospects - March 10, 2026

**Target:** 25 LinkedIn connections via Google Search  
**Time:** Spread over 12 hours (1 per ~30 min)  
**Goal:** 7-10 acceptances, 2-3 conversations, 1 hot lead

---

## 🔥 PRIORITY 1-5 (Connect First)

| # | Asset Class | Price | Full Name | Company | LinkedIn Search |
|---|-------------|-------|-----------|---------|-----------------|
| 1 | Industrial/Commercial Portfolio | $294M | [Find President/CEO](https://www.google.com/search?q=Mississauga+industrial+portfolio+buyer+2022+linkedin+president+CEO) | Mississauga Portfolio Buyer | [Search](https://www.google.com/search?q=Mississauga+industrial+portfolio+buyer+2022+linkedin+president+CEO) |
| 2 | Land (10 acres) | $44M | [Find Land Developer](https://www.google.com/search?q=Vaughan+land+developer+2022+"Conc+9"+linkedin+president) | Vaughan Land Assembler | [Search](https://www.google.com/search?q=Vaughan+land+developer+2022+"Conc+9"+linkedin+president) |
| 3 | Commercial/Development | $30M | [Find Developer](https://www.google.com/search?q="60+East+Beaver+Creek"+Richmond+Hill+buyer+2022+linkedin+developer) | Richmond Hill Development Buyer | [Search](https://www.google.com/search?q="60+East+Beaver+Creek"+Richmond+Hill+buyer+2022+linkedin+developer) |
| 4 | Medical/Commercial | $18.7M | [Find Medical Investor](https://www.google.com/search?q="4949+Bathurst"+North+York+medical+office+buyer+2022+linkedin+president) | North York Medical Buyer | [Search](https://www.google.com/search?q="4949+Bathurst"+North+York+medical+office+buyer+2022+linkedin+president) |
| 5 | Land (47 acres) | $16.5M | [Find Land Buyer](https://www.google.com/search?q="15600+Jane"+King+City+land+buyer+2022+linkedin) | King City Land Buyer | [Search](https://www.google.com/search?q="15600+Jane"+King+City+land+buyer+2022+linkedin) |

---

## 📊 PRIORITY 6-15 (Portfolio & Mixed-Use Buyers)

| # | Asset Class | Price | Full Name | Company | LinkedIn Search |
|---|-------------|-------|-----------|---------|-----------------|
| 6 | Mixed Portfolio | $12.3M | [Find Investor](https://www.google.com/search?q=Brockton+Heritage+Way+real+estate+buyer+linkedin) | Brockton Portfolio Investor | [Search](https://www.google.com/search?q=Brockton+Heritage+Way+real+estate+buyer+linkedin) |
| 7 | Development Site | $10.8M | [Find Developer](https://www.google.com/search?q="3905+Keele"+North+York+developer+buyer+linkedin) | North York Development Buyer | [Search](https://www.google.com/search?q="3905+Keele"+North+York+developer+buyer+linkedin) |
| 8 | Downtown Mixed-Use | $372M | [Find Downtown Developer](https://www.google.com/search?q="King+St+W"+Oshawa+downtown+buyer+2022+linkedin+developer+president) | Oshawa Downtown Portfolio | [Search](https://www.google.com/search?q="King+St+W"+Oshawa+downtown+buyer+2022+linkedin+developer+president) |
| 9 | Land (Milton) | $361M | [Find Land Corp](https://www.google.com/search?q="Boston+Church"+Milton+land+developer+linkedin) | Milton Land Corporation | [Search](https://www.google.com/search?q="Boston+Church"+Milton+land+developer+linkedin) |
| 10 | Land/Estate | $324M | [Find Estate Buyer](https://www.google.com/search?q="12861+Dixie"+Caledon+real+estate+buyer+linkedin) | Caledon Estate Buyer | [Search](https://www.google.com/search?q="12861+Dixie"+Caledon+real+estate+buyer+linkedin) |
| 11 | Commercial (Bay St) | $300M | [Find Institutional Buyer](https://www.google.com/search?q="200+Bay+St"+Toronto+buyer+2022+linkedin+CEO) | Toronto Financial District | [Search](https://www.google.com/search?q="200+Bay+St"+Toronto+buyer+2022+linkedin+CEO) |
| 12 | Mixed-Use Waterfront | $300M | [Find Waterfront Dev](https://www.google.com/search?q="123+Queen+St"+Toronto+waterfront+buyer+linkedin) | Toronto Waterfront Buyer | [Search](https://www.google.com/search?q="123+Queen+St"+Toronto+waterfront+buyer+linkedin) |
| 13 | Office Portfolio | $300M | [Find Office Investor](https://www.google.com/search?q="155+Wellington"+Toronto+office+buyer+linkedin) | Toronto Wellington Portfolio | [Search](https://www.google.com/search?q="155+Wellington"+Toronto+office+buyer+linkedin) |
| 14 | Luxury Commercial | $300M | [Find Luxury Buyer](https://www.google.com/search?q="27+Yorkville"+Toronto+luxury+buyer+linkedin) | Yorkville Luxury Buyer | [Search](https://www.google.com/search?q="27+Yorkville"+Toronto+luxury+buyer+linkedin) |
| 15 | Industrial | $296M | [Find Industrial Buyer](https://www.google.com/search?q="10348+Warden"+Markham+industrial+buyer+linkedin) | Markham Industrial Buyer | [Search](https://www.google.com/search?q="10348+Warden"+Markham+industrial+buyer+linkedin) |

---

## 🏢 PRIORITY 16-25 (Toronto & Regional Buyers)

| # | Asset Class | Price | Full Name | Company | LinkedIn Search |
|---|-------------|-------|-----------|---------|-----------------|
| 16 | Corporate/Commercial | $278M | [Find Corporate Buyer](https://www.google.com/search?q="6880+Financial"+Mississauga+corporate+buyer+linkedin) | Mississauga Corporate Centre | [Search](https://www.google.com/search?q="6880+Financial"+Mississauga+corporate+buyer+linkedin) |
| 17 | Transit-Oriented Mixed | $275M | [Find TOD Buyer](https://www.google.com/search?q="1+Front+St"+Toronto+union+station+buyer+linkedin) | Toronto Front Street | [Search](https://www.google.com/search?q="1+Front+St"+Toronto+union+station+buyer+linkedin) |
| 18 | Retail/Commercial | $272M | [Find Retail Buyer](https://www.google.com/search?q="5100+Erin+Mills"+Mississauga+buyer+2022+linkedin) | Mississauga Erin Mills | [Search](https://www.google.com/search?q="5100+Erin+Mills"+Mississauga+buyer+2022+linkedin) |
| 19 | University Town Mixed | $270M | [Find Waterloo Dev](https://www.google.com/search?q="550+King+St+N"+Waterloo+development+buyer+2022+linkedin+president+CEO) | Waterloo Region Developer | [Search](https://www.google.com/search?q="550+King+St+N"+Waterloo+development+buyer+2022+linkedin+president+CEO) |
| 20 | Retail (Eaton Centre) | $263M | [Find Retail Investor](https://www.google.com/search?q="176+Yonge"+Toronto+Eaton+Centre+buyer+linkedin) | Toronto Yonge Street | [Search](https://www.google.com/search?q="176+Yonge"+Toronto+Eaton+Centre+buyer+linkedin) |
| 21 | Financial Office | $263M | [Find Financial Buyer](https://www.google.com/search?q="483+Bay"+Toronto+financial+buyer+linkedin) | Toronto Bay Street | [Search](https://www.google.com/search?q="483+Bay"+Toronto+financial+buyer+linkedin) |
| 22 | Luxury Retail (Mink Mile) | $262M | [Find Luxury Retail](https://www.google.com/search?q="2+Bloor+St+W"+Toronto+Mink+Mile+buyer+linkedin) | Toronto Bloor/Yonge | [Search](https://www.google.com/search?q="2+Bloor+St+W"+Toronto+Mink+Mile+buyer+linkedin) |
| 23 | Waterfront Mixed | $261M | [Find Waterfront Dev](https://www.google.com/search?q="207+Queens+Quay"+Toronto+waterfront+buyer+linkedin) | Toronto Queens Quay | [Search](https://www.google.com/search?q="207+Queens+Quay"+Toronto+waterfront+buyer+linkedin) |
| 24 | Airport Industrial | $253M | [Find Industrial](https://www.google.com/search?q="7900+Airport"+Brampton+industrial+buyer+linkedin) | Brampton Airport Lands | [Search](https://www.google.com/search?q="7900+Airport"+Brampton+industrial+buyer+linkedin) |
| 25 | Iconic Mixed-Use | $250M | [Find Iconic Buyer](https://www.google.com/search?q="1+Yonge+St"+Toronto+One+buyer+linkedin+CEO) | Toronto Yonge/Dundas | [Search](https://www.google.com/search?q="1+Yonge+St"+Toronto+One+buyer+linkedin+CEO) |

---

## ⏰ DAILY SCHEDULE

### **Morning Block (Prospects 1-8)**
- 9:00 AM - Prospect #1
- 9:30 AM - Prospect #2
- 10:00 AM - Prospect #3
- 10:30 AM - Prospect #4
- 11:00 AM - Prospect #5
- 11:30 AM - Prospect #6
- 12:00 PM - Prospect #7
- 12:30 PM - Prospect #8

### **Afternoon Block (Prospects 9-17)**
- 2:00 PM - Prospect #9
- 2:30 PM - Prospect #10
- 3:00 PM - Prospect #11
- 3:30 PM - Prospect #12
- 4:00 PM - Prospect #13
- 4:30 PM - Prospect #14
- 5:00 PM - Prospect #15
- 5:30 PM - Prospect #16
- 6:00 PM - Prospect #17

### **Evening Block (Prospects 18-25)**
- 7:30 PM - Prospect #18
- 8:00 PM - Prospect #19
- 8:30 PM - Prospect #20
- 9:00 PM - Prospect #21
- 9:30 PM - Prospect #22
- 10:00 PM - Prospect #23
- 10:30 PM - Prospect #24
- 11:00 PM - Prospect #25

---

## 📝 CONNECTION SCRIPT

**Message (Copy-Paste, Personalize Name):**
```
Hi [Name],

I came across your profile while researching the [address/area] acquisition. 
Impressive transaction.

I'm active in Ontario commercial real estate - primarily Niagara region 
development. Would value connecting with someone who understands this market.

Best,
[Your Name]
```

---

## 📊 TRACKING

| Metric | Target | Actual |
|--------|--------|--------|
| **Connection Requests Sent** | 25 | ___ |
| **Accepted** | 7-10 (30-40%) | ___ |
| **Responded** | 3-5 | ___ |
| **Phone Calls Scheduled** | 1-2 | ___ |
| **Hot Leads** | 1 | ___ |

---

## ✅ END OF DAY CHECKLIST

- [ ] All 25 Google searches completed
- [ ] All 25 LinkedIn connection requests sent
- [ ] Personalized messages used (not generic)
- [ ] Spaced requests throughout day (not all at once)
- [ ] Results logged above
- [ ] Tomorrow's 25 prospects prepared

---

**Tomorrow's File:** `Daily_25_Prospects_2026-03-11.md`

*Generated by Kimi Claw AI*