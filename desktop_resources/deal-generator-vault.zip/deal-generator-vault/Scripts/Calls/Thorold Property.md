# Call Scripts - Thorold Property ($4.82M)

## Property Quick Reference
- **Address:** 75 Ormond Street South, Thorold, ON
- **Price:** $4,820,000
- **Status:** ✅ SPA Approved
- **Units:** 241
- **Size:** 1.7 acres
- **Type:** Multi-Residential Development (9-14 storey)
- **Key Selling Points:**
  - SPA APPROVED - ready to build
  - 5 min from Brock University
  - 15 min from Niagara Falls
  - Phase 1 & 2 ESA complete

---

## Script 1: Glen Alizadeh - Performance Auto Group

**Background:** $16.25M cash deal, St. Catharines (15 min away), 95% match

### Opening:
"Hi Glen, this is [Your Name]. I hope I'm not catching you at a bad time. I'm calling about a development opportunity in Thorold that I think might interest you given your recent activity in the Niagara market."

### Hook:
"I saw you closed on that $16 million deal in St. Catharines back in February - impressive transaction. I'm representing a SPA-approved development site literally 15 minutes from you in Thorold."

### Pitch:
"It's 1.7 acres, zoned for 241 units, 9-14 storeys. SPA is already approved, so it's shovel-ready. Asking $4.82 million. Given your capacity and local presence, I thought you'd want first look before we go broader with marketing."

### Questions:
- "Are you currently looking for development opportunities in the Niagara region?"
- "Does the unit count and price point fit your current investment criteria?"
- "Would you like me to send over the site plan and pro forma?"

### Close:
"I can have the full package to you within the hour. Can we schedule a site walk this week? I'm flexible on timing."

### Objection Handling:

**"I'm not looking right now"**
"I understand - most of my serious buyers weren't officially 'looking' either until they saw this specific opportunity. The SPA approval and location are pretty unique. Worth a 5-minute site visit?"

**"The price seems high"**
"At $20,000 per door with SPA approval in hand, we're priced below comparable sites in St. Catharines and Hamilton. Happy to share the comparables."

**"Send me the information"**
"Absolutely - I'll send the investment brief right after this call. What's your email? And can I follow up Thursday to see if you have questions?"

---

## Script 2: Christopher Zeppa - City Park Homes

**Background:** Land developer, just spent $13.25M on 18 acres, 92% match

### Opening:
"Hi Christopher, [Your Name] here. I'm calling about a development site that seems right in your wheelhouse given your recent land acquisition."

### Hook:
"I know City Park Homes just picked up that 18-acre parcel. I'm representing a complementary site - smaller scale, but shovel-ready with SPA approval."

### Pitch:
"1.7 acres in Thorold, approved for 241 units, 9-14 storeys. It's essentially a turnkey development play at $4.82 million. I know you specialize in land, but this is land PLUS approvals - saves 18-24 months."

### Angle:
"Perfect for your pipeline while you're entitling the larger site. Cash flow in 2-3 years instead of 5."

---

## Script 3: Michael Rockall - Larkin Investments

**Background:** $66M developer, Woodbridge, active deal flow, 93% match

### Opening:
"Michael, [Your Name]. I'm calling about a Niagara development opportunity that fits the scale you're currently working at."

### Hook:
"Larkin has been busy - I saw the deal flow you've had this year. I've got a $4.82 million development site that might be a quick add to your portfolio."

### Pitch:
"SPA-approved, 241 units, Niagara region. It's not a massive site, but it's clean, entitled, and ready to go. Sometimes the smaller deals have better returns than the trophy assets."

### Questions:
- "Is Larkin looking at smaller development plays right now?"
- "Do you have bandwidth for a quick-turn project?"

---

## Follow-Up Templates

### Email Follow-Up (Same Day)
```
Subject: {{Property Address}} - Investment Brief

{{Name}},

Thanks for the conversation today. As promised, attached is the investment brief for the Thorold development site:

Key Highlights:
• 1.7 acres | 241 units | 9-14 storeys
• SPA APPROVED - shovel ready
• $4.82 million ($20,000/door)
• 5 min from Brock University
• Phase 1 & 2 ESA complete

I'd like to get you on site this week. Are you available {{Day}} or {{Day2}}?

Best,
[Your Name]
[Phone]
```

### LinkedIn Follow-Up
```
{{Name}}, great speaking with you today about the Thorold development opportunity. Looking forward to showing you the site. {{Property Brief Link}}
```

---

## Tracking Sheet

| Contact | Date Called | Result | Follow-Up Date | Status |
|---------|-------------|--------|----------------|--------|
| Glen Alizadeh | | | | |
| Christopher Zeppa | | | | |
| Michael Rockall | | | | |
| Max Elkaim | | | | |
| Ali Arbab | | | | |