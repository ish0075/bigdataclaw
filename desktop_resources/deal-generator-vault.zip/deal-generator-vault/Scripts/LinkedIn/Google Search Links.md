# LinkedIn Outreach - Google Search Method

## Why Google Search Links?

✅ **More reliable** than direct LinkedIn URLs (which change)  
✅ **Shows context** - see company, title, mutual connections before clicking  
✅ **Finds right person** - even with common names  
✅ **Quick verification** - confirms active profile  
✅ **B2B friendly** - Google indexes LinkedIn better than direct links

---

## 🔗 How to Create Google Search Links

### Formula:
```
https://www.google.com/search?q=FIRST+LAST+COMPANY+linkedin+TITLE
```

### Examples:

**For Developers:**
```
https://www.google.com/search?q=John+Smith+ABC+Development+linkedin+CEO
https://www.google.com/search?q=Jane+Doe+XYZ+Homes+linkedin+president
```

**For Investors:**
```
https://www.google.com/search?q=Bob+Johnson+Real+Estate+Investments+linkedin+principal
https://www.google.com/search?q=Sarah+Lee+Capital+Partners+linkedin+director
```

**For Corporate Buyers:**
```
https://www.google.com/search?q=David+Brown+REIT+linkedin+VP+acquisitions
https://www.google.com/search?q=Lisa+Wang+Property+Group+linkedin+investment+manager
```

---

## 🎯 Your Priority Buyers - Google Links

### 🔥 HOT LEADS (Call Today)

| Buyer | Company | Phone | Google LinkedIn Search |
|-------|---------|-------|------------------------|
| **Glen Alizadeh** | Performance Auto Group | [905-452-1305](tel:9054521305) | [Search](https://www.google.com/search?q=Glen+Alizadeh+Performance+Auto+Group+linkedin+president) |
| **Christopher Zeppa** | City Park Homes | [905-552-5200](tel:9055525200) | [Search](https://www.google.com/search?q=Christopher+Zeppa+City+Park+Homes+linkedin+president) |
| **Michael Rockall** | Larkin Investments | [905-452-1305](tel:9054521305) | [Search](https://www.google.com/search?q=Michael+Rockall+Larkin+Investments+linkedin) |

### 🎯 WARM LEADS (Call This Week)

| Buyer | Company | Phone | Google LinkedIn Search |
|-------|---------|-------|------------------------|
| **Max Elkaim** | 2381070 Ontario Ltd | [647-729-9552](tel:6477299552) | [Search](https://www.google.com/search?q=Max+Elkaim+real+estate+developer+linkedin) |
| **Ali Alex Arbab** | Royal Living Development | [289-755-7500](tel:2897557500) | [Search](https://www.google.com/search?q=Ali+Arbab+Royal+Living+Development+linkedin+president) |
| **David Barry** | 20 Bradmon Inc | (Find phone) | [Search](https://www.google.com/search?q=David+Barry+20+Bradmon+Inc+linkedin) |

---

## 📧 LinkedIn Connection Message Template

### Step 1: Google Search
Click the Google link above → Review their LinkedIn profile → Confirm it's the right person

### Step 2: Send Connection Request

**Option A - Reference Recent Deal:**
```
Hi [Name],

I came across your profile while researching the [recent deal/area]. 
Impressive work with [specific detail].

I'm active in Ontario commercial real estate and would value 
connecting with someone who knows the [market/area] well.

Best,
[Your Name]
```

**Option B - Local Connection:**
```
Hi [Name],

I see you're based in [City] and active in [asset class]. 
I'm working on some interesting opportunities in the region.

Would love to connect and share market insights.

Best,
[Your Name]
```

**Option C - Mutual Interest:**
```
Hi [Name],

Noticed your background in [specific area]. I'm focused on 
[similar area] in Ontario.

Given our similar interests, thought it would make sense to connect.

Best,
[Your Name]
```

### Step 3: Follow-Up (After They Accept)

Wait 24-48 hours, then:

```
[Name], thanks for connecting.

Quick question: Are you currently looking at any development 
opportunities in the $5M range?

I have a SPA-approved site in [Location] that might fit your 
criteria - 241 units, shovel-ready.

Worth a brief conversation?

[Your Name]
```

---

## 🔍 Finding New Buyers - Google Search Queries

### Search These in Google:

**For Developers:**
```
site:linkedin.com "real estate developer" "Ontario" "multi-family"
site:linkedin.com "land development" "Niagara" "principal"
site:linkedin.com "development company" "Toronto" "CEO"
```

**For Investors:**
```
site:linkedin.com "real estate investor" "Ontario" "apartments"
site:linkedin.com "investment manager" "commercial real estate" "Canada"
site:linkedin.com "acquisitions" "real estate" "VP"
```

**For 1031 Exchange Buyers:**
```
site:linkedin.com "1031 exchange" "buyer" "Ontario"
site:linkedin.com "tax deferred" "real estate" "investor"
```

**For Hot Money Sellers (Recent Large Deals):**
```
site:linkedin.com "sold" "Mississauga" "real estate" "2026"
site:linkedin.com "closed" "development" "Toronto" "portfolio"
```

---

## 📊 Tracking Your Outreach

Add to your Daily Note:

```markdown
## LinkedIn Outreach Today

| Name | Company | Google Search | Connected? | Messaged? | Response |
|------|---------|---------------|------------|-----------|----------|
| | | | | | |

## New Connections
- [ ] 

## Follow-ups Needed
- [ ] 
```

---

## ⚡ Quick Access Links

### Your Top 3 (Bookmark These):

1. **Glen Alizadeh**  
   [Google Search](https://www.google.com/search?q=Glen+Alizadeh+Performance+Auto+Group+linkedin+president)  
   Phone: [905-452-1305](tel:9054521305)

2. **Christopher Zeppa**  
   [Google Search](https://www.google.com/search?q=Christopher+Zeppa+City+Park+Homes+linkedin+president)  
   Phone: [905-552-5200](tel:9055525200)

3. **Michael Rockall**  
   [Google Search](https://www.google.com/search?q=Michael+Rockall+Larkin+Investments+linkedin)  
   Phone: [905-452-1305](tel:9054521305)

---

## ✅ Daily LinkedIn Routine

**Morning (10 min):**
- [ ] Check Google alerts for new buyers
- [ ] Send 3-5 connection requests (personalized)
- [ ] Respond to any messages

**Evening (10 min):**
- [ ] Follow up with new connections
- [ ] Engage on 2-3 posts (comment/like)
- [ ] Log activity in Obsidian

**Weekly (30 min):**
- [ ] Post market insight
- [ ] Review outreach results
- [ ] Adjust targeting based on responses

---

## 🎯 Goal: 20 Quality Connections This Week

Target: 3-5 new connections per day  
Conversion: 20% accept and engage  
Result: 4 serious conversations  
Pipeline: 1-2 hot prospects

---

*Remember: Quality over quantity. Personalize every request. Reference specific deals/projects. Build rapport before pitching.*