---
type: dashboard
created: 2026-03-09
updated: {{date:YYYY-MM-DD}}
---

# 🎯 Deal Generator Command Center

**First Close Target:** 30-90 Days  
**Status:** 🔥 ACTIVE HUNTING

---

## 📊 LIVE METRICS

| Metric | Current | Target |
|--------|---------|--------|
| **Total Buyers** | 2,745 | 5,000 |
| **Hot Money Sellers** | 50+ | 100 |
| **Active Matches** | 50 | 200 |
| **This Week's Calls** | [[Daily/{{date:YYYY-MM-DD}}\|0]] | 20 |
| **LOIs Generated** | 0 | 5 |
| **Days to First Close** | 90 | 30-90 |

---

## ⚡ TODAY'S PRIORITIES

### 🔗 Quick Access - LinkedIn Google Search
| Buyer | Google Search | Phone | Status |
|-------|---------------|-------|--------|
| **Glen Alizadeh** | [Search](https://www.google.com/search?q=Glen+Alizadeh+Performance+Auto+Group+linkedin+president) | [905-452-1305](tel:9054521305) | 🔥 Call Today |
| **Christopher Zeppa** | [Search](https://www.google.com/search?q=Christopher+Zeppa+City+Park+Homes+linkedin+president) | [905-552-5200](tel:9055525200) | 🔥 Call Today |
| **Michael Rockall** | [Search](https://www.google.com/search?q=Michael+Rockall+Larkin+Investments+linkedin) | [905-452-1305](tel:9054521305) | 🔥 Call Today |

### 📞 CALLS TO MAKE
- [ ] [[Glen Alizadeh]] - Use script in buyer profile
- [ ] [[Christopher Zeppa]] - Land developer angle
- [ ] [[Michael Rockall]] - Active developer pitch

### 📧 LINKEDIN OUTREACH
- [ ] Connect with Glen via [Google Search](https://www.google.com/search?q=Glen+Alizadeh+Performance+Auto+Group+linkedin+president)
- [ ] Connect with Christopher via [Google Search](https://www.google.com/search?q=Christopher+Zeppa+City+Park+Homes+linkedin+president)
- [ ] Connect with Michael via [Google Search](https://www.google.com/search?q=Michael+Rockall+Larkin+Investments+linkedin)

---

## 🏢 ACTIVE PROPERTIES

| Property | Price | Status | Matches | Top Buyer |
|----------|-------|--------|---------|-----------|
| [[75 Ormond St S - Thorold\|Thorold]] | $4.82M | ✅ SPA Approved | 8 | Glen Alizadeh |
| [[London Mixed Development\|London]] | $29.3M | Active | 44 | - |
| [[Niagara High Rise Condo\|Niagara]] | $28.48M | Active | 0 | - |
| [[Mega Development\|Mega]] | $70M | Active | 0 | - |

---

## 💰 HOT MONEY ALERTS (Last 7 Days)
```dataview
TABLE 
  total_value as "Deal Size",
  days_since_close as "Days",
  phone as "Phone"
FROM "Sellers/Hot_Money"
WHERE days_since_close <= 7
SORT total_value DESC
LIMIT 5
```

---

## 📈 PIPELINE STATUS

```mermaid
graph LR
    A[Hot Leads 12] --> B[Contacted 8]
    B --> C[Meeting 3]
    C --> D[LOI 1]
    D --> E[Negotiating 0]
    E --> F[Closed 0]
```

---

## 🎯 90-DAY ROADMAP

- **Week 1-2:** Foundation (database, website, obsidian)
- **Week 3-4:** Activation (first calls, hot money outreach)
- **Month 2:** Scale (all 7 properties active)
- **Month 3:** Close (first deal done)

---

## 🔗 QUICK LINKS

- [[Daily/{{date:YYYY-MM-DD}}|Today's Activity]]
- [[Templates/Buyer Profile|New Buyer Template]]
- [[Templates/Daily Note|Daily Note Template]]
- [[Scripts/Calls/Thorold Property|Thorold Call Script]]
- [[Scripts/LinkedIn/Google Search Links|LinkedIn Google Search Guide]]

---

*Last updated: {{date:YYYY-MM-DD HH:mm}} by Kimi Claw AI*