---
type: buyer
category: hot_money
match_score: 95
priority: call_today
asset_class: multi_residential
capacity: $16.25M
created: {{date:YYYY-MM-DD}}
last_contact: 
next_action: 
status: new
---

# {{Name}}

## 📞 Contact Information
- **Name:** {{Name}}
- **Company:** {{Company}}
- **Phone:** [{{Phone}}](tel:{{Phone}})
- **Email:** 
- **LinkedIn:** 
- **Location:** {{City}}

## 💰 Deal History
- **Recent Deal:** {{Recent_Deal}}
- **Deal Date:** {{Deal_Date}}
- **Asset Class:** 
- **Payment Type:** {{Payment_Type}}
- **Financing Rate:** {{Rate}}%

## 🎯 Match Analysis
- **Match Score:** {{Match_Score}}%
- **Status:** 🔥 HOT
- **Priority:** Call Today
- **Best Property Match:** [[75 Ormond St S - Thorold]]
- **Why Matched:** {{Match_Reason}}

## 💡 Talking Points
- Recent $X deal shows capacity
- Local to {{Region}} market
- All-cash buyer (no financing delays)

## 📝 Communication Log
| Date | Type | Notes | Next Action |
|------|------|-------|-------------|
| {{date:YYYY-MM-DD}} | Created | Added to database | Call within 24h |

---

## 🏷️ Tags
#buyer #hot-money #{{City}} #{{Asset_Class}}